import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PaisesPage } from './paises';

/**
 * Created by leonardo_soares on 28/05/2018.
 * RA 816114026
 */

@NgModule({
  declarations: [
    PaisesPage,
  ],
  imports: [
    IonicPageModule.forChild(PaisesPage),
  ],
})
export class PaisesPageModule {
}